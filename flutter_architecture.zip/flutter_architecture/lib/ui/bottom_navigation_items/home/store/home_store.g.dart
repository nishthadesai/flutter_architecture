// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'home_store.dart';

// **************************************************************************
// StoreGenerator
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, unnecessary_brace_in_string_interps, unnecessary_lambdas, prefer_expression_function_bodies, lines_longer_than_80_chars, avoid_as, avoid_annotating_with_dynamic, no_leading_underscores_for_local_identifiers

mixin _$HomeStore on _HomeStoreBase, Store {
  late final _$categoryResponseAtom =
      Atom(name: '_HomeStoreBase.categoryResponse', context: context);

  @override
  BaseResponse<CategoryModel>? get categoryResponse {
    _$categoryResponseAtom.reportRead();
    return super.categoryResponse;
  }

  @override
  set categoryResponse(BaseResponse<CategoryModel>? value) {
    _$categoryResponseAtom.reportWrite(value, super.categoryResponse, () {
      super.categoryResponse = value;
    });
  }

  late final _$imageResponseAtom =
      Atom(name: '_HomeStoreBase.imageResponse', context: context);

  @override
  ImageModel? get imageResponse {
    _$imageResponseAtom.reportRead();
    return super.imageResponse;
  }

  @override
  set imageResponse(ImageModel? value) {
    _$imageResponseAtom.reportWrite(value, super.imageResponse, () {
      super.imageResponse = value;
    });
  }

  late final _$errorMessageAtom =
      Atom(name: '_HomeStoreBase.errorMessage', context: context);

  @override
  String? get errorMessage {
    _$errorMessageAtom.reportRead();
    return super.errorMessage;
  }

  @override
  set errorMessage(String? value) {
    _$errorMessageAtom.reportWrite(value, super.errorMessage, () {
      super.errorMessage = value;
    });
  }

  late final _$subcategoryResponseAtom =
      Atom(name: '_HomeStoreBase.subcategoryResponse', context: context);

  @override
  BaseResponse<List<SubcategoryListModel>>? get subcategoryResponse {
    _$subcategoryResponseAtom.reportRead();
    return super.subcategoryResponse;
  }

  @override
  set subcategoryResponse(BaseResponse<List<SubcategoryListModel>>? value) {
    _$subcategoryResponseAtom.reportWrite(value, super.subcategoryResponse, () {
      super.subcategoryResponse = value;
    });
  }

  late final _$disposerAtom =
      Atom(name: '_HomeStoreBase.disposer', context: context);

  @override
  List<ReactionDisposer>? get disposer {
    _$disposerAtom.reportRead();
    return super.disposer;
  }

  @override
  set disposer(List<ReactionDisposer>? value) {
    _$disposerAtom.reportWrite(value, super.disposer, () {
      super.disposer = value;
    });
  }

  late final _$currentAddressAtom =
      Atom(name: '_HomeStoreBase.currentAddress', context: context);

  @override
  String get currentAddress {
    _$currentAddressAtom.reportRead();
    return super.currentAddress;
  }

  @override
  set currentAddress(String value) {
    _$currentAddressAtom.reportWrite(value, super.currentAddress, () {
      super.currentAddress = value;
    });
  }

  late final _$fullAddressAtom =
      Atom(name: '_HomeStoreBase.fullAddress', context: context);

  @override
  String get fullAddress {
    _$fullAddressAtom.reportRead();
    return super.fullAddress;
  }

  @override
  set fullAddress(String value) {
    _$fullAddressAtom.reportWrite(value, super.fullAddress, () {
      super.fullAddress = value;
    });
  }

  late final _$currentPositionAtom =
      Atom(name: '_HomeStoreBase.currentPosition', context: context);

  @override
  Position? get currentPosition {
    _$currentPositionAtom.reportRead();
    return super.currentPosition;
  }

  @override
  set currentPosition(Position? value) {
    _$currentPositionAtom.reportWrite(value, super.currentPosition, () {
      super.currentPosition = value;
    });
  }

  late final _$isLoadingAtom =
      Atom(name: '_HomeStoreBase.isLoading', context: context);

  @override
  bool get isLoading {
    _$isLoadingAtom.reportRead();
    return super.isLoading;
  }

  @override
  set isLoading(bool value) {
    _$isLoadingAtom.reportWrite(value, super.isLoading, () {
      super.isLoading = value;
    });
  }

  late final _$categoryDataAsyncAction =
      AsyncAction('_HomeStoreBase.categoryData', context: context);

  @override
  Future<dynamic> categoryData(Map<String, dynamic> data) {
    return _$categoryDataAsyncAction.run(() => super.categoryData(data));
  }

  late final _$subcategoryDataAsyncAction =
      AsyncAction('_HomeStoreBase.subcategoryData', context: context);

  @override
  Future<dynamic> subcategoryData(Map<String, dynamic> data) {
    return _$subcategoryDataAsyncAction.run(() => super.subcategoryData(data));
  }

  late final _$getCurrentPositionAsyncAction =
      AsyncAction('_HomeStoreBase.getCurrentPosition', context: context);

  @override
  Future<void> getCurrentPosition() {
    return _$getCurrentPositionAsyncAction
        .run(() => super.getCurrentPosition());
  }

  late final _$getAddressFromLatLngAsyncAction =
      AsyncAction('_HomeStoreBase.getAddressFromLatLng', context: context);

  @override
  Future<void> getAddressFromLatLng(Position position) {
    return _$getAddressFromLatLngAsyncAction
        .run(() => super.getAddressFromLatLng(position));
  }

  late final _$launchURLAsyncAction =
      AsyncAction('_HomeStoreBase.launchURL', context: context);

  @override
  Future launchURL() {
    return _$launchURLAsyncAction.run(() => super.launchURL());
  }

  late final _$uploadImageAsyncAction =
      AsyncAction('_HomeStoreBase.uploadImage', context: context);

  @override
  Future<dynamic> uploadImage(File data) {
    return _$uploadImageAsyncAction.run(() => super.uploadImage(data));
  }

  @override
  String toString() {
    return '''
categoryResponse: ${categoryResponse},
imageResponse: ${imageResponse},
errorMessage: ${errorMessage},
subcategoryResponse: ${subcategoryResponse},
disposer: ${disposer},
currentAddress: ${currentAddress},
fullAddress: ${fullAddress},
currentPosition: ${currentPosition},
isLoading: ${isLoading}
    ''';
  }
}
