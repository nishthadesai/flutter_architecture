// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a en locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'en';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "BathroomCleaned":
            MessageLookupByLibrary.simpleMessage("•  1 bathroom cleaned"),
        "DkkHour": MessageLookupByLibrary.simpleMessage("140 dkk / hour"),
        "Hour": MessageLookupByLibrary.simpleMessage("+ 1  hour"),
        "KitchenCleaned":
            MessageLookupByLibrary.simpleMessage("•  1 kitchen cleaned"),
        "Reviews": MessageLookupByLibrary.simpleMessage("93 reviews"),
        "aDeepCleanWithFullWipeDownOfAllSurfaces":
            MessageLookupByLibrary.simpleMessage(
                "A deep clean with full wipe down of all surfaces, oven, and more..."),
        "acceptTnC": MessageLookupByLibrary.simpleMessage(
            "Please accept \$tNc \$and \$privacyPolicy"),
        "addEmployee": MessageLookupByLibrary.simpleMessage("Add employee"),
        "addNewCard": MessageLookupByLibrary.simpleMessage("Add New Card"),
        "addNewCardDesc": MessageLookupByLibrary.simpleMessage(
            "Please enter your card details"),
        "additionalBathroom":
            MessageLookupByLibrary.simpleMessage("Additional bathroom"),
        "additionalServices":
            MessageLookupByLibrary.simpleMessage("Additional services"),
        "alreadyHaveAccount":
            MessageLookupByLibrary.simpleMessage("Already have an account?"),
        "alreadyHaveAnAccount":
            MessageLookupByLibrary.simpleMessage("Already have an account?"),
        "and": MessageLookupByLibrary.simpleMessage(" and "),
        "applicationTitle":
            MessageLookupByLibrary.simpleMessage("Flutter Demo Structure"),
        "availableCleaningServices":
            MessageLookupByLibrary.simpleMessage("Available cleaning services"),
        "avgPrice200Dkk":
            MessageLookupByLibrary.simpleMessage("Avg. price 200 dkk"),
        "avgPrice300Dkk":
            MessageLookupByLibrary.simpleMessage("Avg. price 300 dkk"),
        "avgPrice400Dkk":
            MessageLookupByLibrary.simpleMessage("Avg. price 400 dkk"),
        "back": MessageLookupByLibrary.simpleMessage("Back"),
        "backToLogin": MessageLookupByLibrary.simpleMessage("Back to login"),
        "billingAddressIsDifferentThanServiceAddress":
            MessageLookupByLibrary.simpleMessage(
                "Billing address is different than service address"),
        "billingAndPaymentDetails":
            MessageLookupByLibrary.simpleMessage("Billing and payment details"),
        "booking": MessageLookupByLibrary.simpleMessage("Booking"),
        "byContinuingYouAgreeToThe": MessageLookupByLibrary.simpleMessage(
            "By continuing, you agree to the"),
        "camera": MessageLookupByLibrary.simpleMessage("Camera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Cancel"),
        "cancelled": MessageLookupByLibrary.simpleMessage("Cancelled"),
        "carWash": MessageLookupByLibrary.simpleMessage("Car wash"),
        "cardHasExpired":
            MessageLookupByLibrary.simpleMessage("Card has expired"),
        "cardName": MessageLookupByLibrary.simpleMessage("Card Name"),
        "cardNumber": MessageLookupByLibrary.simpleMessage("Card Number"),
        "categoryid": MessageLookupByLibrary.simpleMessage("category_id"),
        "change": MessageLookupByLibrary.simpleMessage("Change"),
        "childcare": MessageLookupByLibrary.simpleMessage("Childcare"),
        "chooseImage": MessageLookupByLibrary.simpleMessage("Choose Image"),
        "confPassword":
            MessageLookupByLibrary.simpleMessage("Confirm Password"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Confirm Password"),
        "confirmPasswordMustBeSameAsPassword":
            MessageLookupByLibrary.simpleMessage(
                "Confirm password must be same as password"),
        "connectTimeout":
            MessageLookupByLibrary.simpleMessage("Connect timeout"),
        "connectionProblem": MessageLookupByLibrary.simpleMessage(
            "There are some problems with the connection. Please try again"),
        "connectionTimedOut": MessageLookupByLibrary.simpleMessage(
            "The connection has timed out. Please try again"),
        "connectionTimeoutWithServer": MessageLookupByLibrary.simpleMessage(
            "Connection timeout with server"),
        "connectionToServerFailedDueToInternetConnection":
            MessageLookupByLibrary.simpleMessage(
                "Connection to server failed due to internet connection."),
        "cooking": MessageLookupByLibrary.simpleMessage("Cooking"),
        "createAccount": MessageLookupByLibrary.simpleMessage("Create account"),
        "cvv": MessageLookupByLibrary.simpleMessage("Cvv"),
        "cvvIsInvalid": MessageLookupByLibrary.simpleMessage("CVV is invalid"),
        "dashboard": MessageLookupByLibrary.simpleMessage("Dashboard"),
        "dataNotFound": MessageLookupByLibrary.simpleMessage("Data not found"),
        "databaseException":
            MessageLookupByLibrary.simpleMessage("Database exception"),
        "deepHouseCleaning":
            MessageLookupByLibrary.simpleMessage("Deep house cleaning"),
        "deepKitchenCleaning":
            MessageLookupByLibrary.simpleMessage("Deep kitchen cleaning"),
        "details": MessageLookupByLibrary.simpleMessage("Details:"),
        "dk": MessageLookupByLibrary.simpleMessage("DK"),
        "dustingAllSurfaces":
            MessageLookupByLibrary.simpleMessage("•  Dusting all surfaces"),
        "email": MessageLookupByLibrary.simpleMessage("Email"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Email Address"),
        "enterAddress": MessageLookupByLibrary.simpleMessage("Enter address"),
        "enterCardName":
            MessageLookupByLibrary.simpleMessage("Please enter card name"),
        "enterCardNumber":
            MessageLookupByLibrary.simpleMessage("Please enter card number"),
        "enterConfirmPassword":
            MessageLookupByLibrary.simpleMessage("Enter confirm password"),
        "enterCvv": MessageLookupByLibrary.simpleMessage("Please enter cvv"),
        "enterEmail": MessageLookupByLibrary.simpleMessage("Enter Email"),
        "enterExpiryDate":
            MessageLookupByLibrary.simpleMessage("Please enter expiry date"),
        "enterFirstName":
            MessageLookupByLibrary.simpleMessage("Enter First Name"),
        "enterLastName":
            MessageLookupByLibrary.simpleMessage("Enter Last Name"),
        "enterMobileNumber":
            MessageLookupByLibrary.simpleMessage("Enter Mobile Number"),
        "enterPassword": MessageLookupByLibrary.simpleMessage("Enter Password"),
        "enterThe4DigitVerificationCodeWeSentToYou":
            MessageLookupByLibrary.simpleMessage(
                "Enter the 4 digit verification code we sent to you via SMS."),
        "enterVatNumber":
            MessageLookupByLibrary.simpleMessage("Enter VAT number"),
        "errorDuringCommunication":
            MessageLookupByLibrary.simpleMessage("Error During Communication:"),
        "errorUploadingPhoto":
            MessageLookupByLibrary.simpleMessage("Error uploading photo"),
        "expiryDate": MessageLookupByLibrary.simpleMessage("Expiry Date"),
        "expiryMonthIsInvalid":
            MessageLookupByLibrary.simpleMessage("Expiry month is invalid"),
        "expiryYearIsInvalid":
            MessageLookupByLibrary.simpleMessage("Expiry year is invalid"),
        "featuredHelpers":
            MessageLookupByLibrary.simpleMessage("Featured helpers:"),
        "fillDetails": MessageLookupByLibrary.simpleMessage(
            "Fill your below detail to create account"),
        "firstName": MessageLookupByLibrary.simpleMessage("First Name"),
        "floorVacuumAndWash":
            MessageLookupByLibrary.simpleMessage("•  Floor vacuum and wash"),
        "forgot": MessageLookupByLibrary.simpleMessage("Forgot?"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Forgot Password?"),
        "fullHouseCleaning":
            MessageLookupByLibrary.simpleMessage("Full house cleaning"),
        "gallery": MessageLookupByLibrary.simpleMessage("Gallery"),
        "getStarted": MessageLookupByLibrary.simpleMessage("Get Started"),
        "giftWrapping": MessageLookupByLibrary.simpleMessage("Gift wrapping"),
        "gota": MessageLookupByLibrary.simpleMessage("Gota"),
        "handyWork": MessageLookupByLibrary.simpleMessage("Handy Work"),
        "haveSomethingSpecificYouNeedHelpWithChooseNumberOf":
            MessageLookupByLibrary.simpleMessage(
                "Have something specific you need help with? Choose number of hours and ..."),
        "hello": MessageLookupByLibrary.simpleMessage("Hello!"),
        "high": MessageLookupByLibrary.simpleMessage("High"),
        "home": MessageLookupByLibrary.simpleMessage("Home"),
        "houseCleaning": MessageLookupByLibrary.simpleMessage("House Cleaning"),
        "howOften": MessageLookupByLibrary.simpleMessage("How often?"),
        "iAgree": MessageLookupByLibrary.simpleMessage("I agree to "),
        "iAmThoroughFriendlyAndHonestIWillLeaveYour":
            MessageLookupByLibrary.simpleMessage(
                "I am thorough, friendly and honest. I will leave your sp..."),
        "iCanHelpYouWith":
            MessageLookupByLibrary.simpleMessage("I can help you with"),
        "iNeedHelpWith":
            MessageLookupByLibrary.simpleMessage("I need help with:"),
        "invalidCredentials":
            MessageLookupByLibrary.simpleMessage("Invalid credentials"),
        "invalidInput": MessageLookupByLibrary.simpleMessage("Invalid Input:"),
        "invalidRequest":
            MessageLookupByLibrary.simpleMessage("Invalid Request:"),
        "janeSmith": MessageLookupByLibrary.simpleMessage("Jane Smith"),
        "jasonRoy": MessageLookupByLibrary.simpleMessage("Jason Roy"),
        "kConfPassword": MessageLookupByLibrary.simpleMessage(
            "Please enter confirm password"),
        "kConfirm": MessageLookupByLibrary.simpleMessage("Confirm"),
        "kDeleteAccount": MessageLookupByLibrary.simpleMessage(
            "Are you sure \n\nYou want to delete account?"),
        "kEmptyField": MessageLookupByLibrary.simpleMessage(
            "Please enter email address or mobile number"),
        "kEnterCountryCode":
            MessageLookupByLibrary.simpleMessage("Please enter country code"),
        "kEnterEmailAddress":
            MessageLookupByLibrary.simpleMessage("Please enter email address"),
        "kEnterFirstName":
            MessageLookupByLibrary.simpleMessage("Please enter first name"),
        "kEnterLastName":
            MessageLookupByLibrary.simpleMessage("Please enter last name"),
        "kEnterMobileNumber":
            MessageLookupByLibrary.simpleMessage("Please enter mobile number"),
        "kEnterNewPassword":
            MessageLookupByLibrary.simpleMessage("Please enter new password"),
        "kEnterPassword":
            MessageLookupByLibrary.simpleMessage("Please enter password"),
        "kEnterValidEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Please enter valid email address"),
        "kEnterValidFirstName": MessageLookupByLibrary.simpleMessage(
            "Please enter at least 1 character for first name"),
        "kEnterValidLastName": MessageLookupByLibrary.simpleMessage(
            "Please enter at least 3 characters for last name"),
        "kEnterValidMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Please enter valid mobile number"),
        "kEnterValidPassword": MessageLookupByLibrary.simpleMessage(
            "Password should be 8 or more characters"),
        "kLogoutMsg": MessageLookupByLibrary.simpleMessage(
            "Are you sure \n\nYou want to logout?"),
        "kPleaseEnterOtp":
            MessageLookupByLibrary.simpleMessage("Please enter OTP"),
        "kPleaseEnterValidOtp":
            MessageLookupByLibrary.simpleMessage("Please enter valid OTP"),
        "lastName": MessageLookupByLibrary.simpleMessage("Last Name"),
        "latitude": MessageLookupByLibrary.simpleMessage("latitude"),
        "locationPermissionsAreDenied": MessageLookupByLibrary.simpleMessage(
            "Location permissions are denied"),
        "locationPermissionsArePermanentlyDeniedWeCannotRequestPermissions":
            MessageLookupByLibrary.simpleMessage(
                "Location permissions are permanently denied, we cannot request permissions."),
        "logIn": MessageLookupByLibrary.simpleMessage("Log in"),
        "login": MessageLookupByLibrary.simpleMessage("Login"),
        "loginInformation":
            MessageLookupByLibrary.simpleMessage("Login information"),
        "loginToContinue":
            MessageLookupByLibrary.simpleMessage("Login to continue."),
        "logout": MessageLookupByLibrary.simpleMessage("Logout"),
        "longitude": MessageLookupByLibrary.simpleMessage("longitude"),
        "loremIpsumIsSimplyDummyTextOfThePrintingAnd":
            MessageLookupByLibrary.simpleMessage(
                "Lorem Ipsum is simply dummy text of the printing and typesetting industry"),
        "low": MessageLookupByLibrary.simpleMessage("Low"),
        "mathTutoring": MessageLookupByLibrary.simpleMessage("Math tutoring"),
        "medium": MessageLookupByLibrary.simpleMessage("Medium"),
        "mobNumber": MessageLookupByLibrary.simpleMessage("Mobile Number"),
        "mobileNumber": MessageLookupByLibrary.simpleMessage("Mobile Number"),
        "moveInOutCleaning":
            MessageLookupByLibrary.simpleMessage("Move in / out  cleaning"),
        "myBookings2": MessageLookupByLibrary.simpleMessage("My Bookings(2)"),
        "name": MessageLookupByLibrary.simpleMessage("Name"),
        "needToRegister":
            MessageLookupByLibrary.simpleMessage("Need to register"),
        "newyorkUsa": MessageLookupByLibrary.simpleMessage("Newyork, USA"),
        "next": MessageLookupByLibrary.simpleMessage("Next"),
        "no": MessageLookupByLibrary.simpleMessage("No"),
        "noActiveInternetConnection": MessageLookupByLibrary.simpleMessage(
            "No Active Internet Connection"),
        "noConnection": MessageLookupByLibrary.simpleMessage("No Connection"),
        "noDataFound": MessageLookupByLibrary.simpleMessage("No data found"),
        "noImageSelected":
            MessageLookupByLibrary.simpleMessage("No image selected"),
        "numberIsInvalid":
            MessageLookupByLibrary.simpleMessage("Card is invalid"),
        "ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "or": MessageLookupByLibrary.simpleMessage("Or"),
        "other": MessageLookupByLibrary.simpleMessage("Other"),
        "otpSentSuccesfully":
            MessageLookupByLibrary.simpleMessage("Otp sent succesfully"),
        "ourTaskersWillMakeYourSpaceShine":
            MessageLookupByLibrary.simpleMessage(
                "Our taskers will make your space shine!"),
        "ovenCleaning": MessageLookupByLibrary.simpleMessage("Oven cleaning"),
        "password": MessageLookupByLibrary.simpleMessage("Password"),
        "passwordMismatch": MessageLookupByLibrary.simpleMessage(
            "Password and Confirm password not match"),
        "paymentMethod": MessageLookupByLibrary.simpleMessage("Payment method"),
        "permissionDeniedAlwaysUserNeedToAllowManually":
            MessageLookupByLibrary.simpleMessage(
                "Permission denied always user need to allow manually"),
        "permissionDeniedPleaseGivePermission":
            MessageLookupByLibrary.simpleMessage(
                "Permission denied, please give permission"),
        "petCare": MessageLookupByLibrary.simpleMessage("Pet Care"),
        "photoPermission":
            MessageLookupByLibrary.simpleMessage("Photo Permission"),
        "pickAnImage": MessageLookupByLibrary.simpleMessage("Pick an Image"),
        "pickAudio": MessageLookupByLibrary.simpleMessage("Pick Audio"),
        "pickDocuments": MessageLookupByLibrary.simpleMessage("Pick Documents"),
        "pickImage": MessageLookupByLibrary.simpleMessage("Pick Image"),
        "pickVideo": MessageLookupByLibrary.simpleMessage("Pick Video"),
        "pickedFileCount":
            MessageLookupByLibrary.simpleMessage("Picked file count: "),
        "pleaseAcceptPrivacyPolicy": MessageLookupByLibrary.simpleMessage(
            "Please accept privacy policy"),
        "pleaseCheckInternetConnection": MessageLookupByLibrary.simpleMessage(
            "Please check internet connection"),
        "pleaseCheckYourInternetConnection":
            MessageLookupByLibrary.simpleMessage(
                "Please check your internet connection"),
        "pleaseCheckYourInternetConnectivityAndTryAgain":
            MessageLookupByLibrary.simpleMessage(
                "Please check your internet connectivity and try again"),
        "pleaseEnter4DigitOtp":
            MessageLookupByLibrary.simpleMessage("Please enter 4 digit otp"),
        "pleaseEnterAddress":
            MessageLookupByLibrary.simpleMessage("Please enter address"),
        "pleaseEnterOtp":
            MessageLookupByLibrary.simpleMessage("Please enter otp"),
        "pleaseEnterVatNumber":
            MessageLookupByLibrary.simpleMessage("Please enter vat number"),
        "pleaseFillFormProperly":
            MessageLookupByLibrary.simpleMessage("Please fill form properly"),
        "pleaseLoginAgain":
            MessageLookupByLibrary.simpleMessage("Please login again."),
        "pleaseSelectFrequency":
            MessageLookupByLibrary.simpleMessage("Please select frequency"),
        "pleaseTurnOnInternetConnection": MessageLookupByLibrary.simpleMessage(
            "Please turn on internet Connection"),
        "pleaseTurnOnLocation":
            MessageLookupByLibrary.simpleMessage("Please turn on location"),
        "popularProjectsInYourArea": MessageLookupByLibrary.simpleMessage(
            "Popular projects in your area"),
        "prahladNagar": MessageLookupByLibrary.simpleMessage("Prahlad Nagar"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Privacy Policy."),
        "profile": MessageLookupByLibrary.simpleMessage("Profile"),
        "profileInformation":
            MessageLookupByLibrary.simpleMessage("Profile information"),
        "readLess": MessageLookupByLibrary.simpleMessage("Read Less"),
        "readMore": MessageLookupByLibrary.simpleMessage("Read more"),
        "receiveTimeout":
            MessageLookupByLibrary.simpleMessage("Receive timeout"),
        "requestCantBeHandledForNowPleaseTryAfterSometime":
            MessageLookupByLibrary.simpleMessage(
                "Request can\'t be handled for now. Please try after sometime."),
        "requestToServerWasCancelled": MessageLookupByLibrary.simpleMessage(
            "Request to server was cancelled"),
        "resend": MessageLookupByLibrary.simpleMessage("Resend"),
        "responseNull":
            MessageLookupByLibrary.simpleMessage("Response is null"),
        "retry": MessageLookupByLibrary.simpleMessage("Retry"),
        "sanneWasWonderfulWithMySonWhoNeededLovingCare":
            MessageLookupByLibrary.simpleMessage(
                "“Sanne was wonderful with my son who needed loving care with math...”"),
        "search": MessageLookupByLibrary.simpleMessage("Search..."),
        "selectFrequencyForCleaning": MessageLookupByLibrary.simpleMessage(
            "Select frequency for cleaning"),
        "selectYourPhoneCode":
            MessageLookupByLibrary.simpleMessage("Select your phone code"),
        "sendTimeout": MessageLookupByLibrary.simpleMessage("Send timeout"),
        "serverError": MessageLookupByLibrary.simpleMessage("Server error."),
        "serverNotFound":
            MessageLookupByLibrary.simpleMessage("Server not found"),
        "serverUnknownError":
            MessageLookupByLibrary.simpleMessage("Server unknown error"),
        "signInWith": MessageLookupByLibrary.simpleMessage("Sign In With"),
        "signUp": MessageLookupByLibrary.simpleMessage("Sign up"),
        "signUpContinueToConfirmation": MessageLookupByLibrary.simpleMessage(
            "Sign up & continue to confirmation"),
        "skip": MessageLookupByLibrary.simpleMessage("Skip"),
        "sola": MessageLookupByLibrary.simpleMessage("Sola"),
        "somethingWentWrongPleaseTryAfterSometime":
            MessageLookupByLibrary.simpleMessage(
                "Something went wrong. Please try after sometime."),
        "somethingWhenWrongPleaseTryAgain":
            MessageLookupByLibrary.simpleMessage(
                "Something when wrong. Please try again."),
        "successfullySignedUp":
            MessageLookupByLibrary.simpleMessage("Successfully Signed up"),
        "tNc": MessageLookupByLibrary.simpleMessage("Terms & Conditions"),
        "taskDetails": MessageLookupByLibrary.simpleMessage("Task Details"),
        "tasksAroundTheHouse":
            MessageLookupByLibrary.simpleMessage("Tasks around the house"),
        "termsOfService":
            MessageLookupByLibrary.simpleMessage("Terms of Service"),
        "thaltej": MessageLookupByLibrary.simpleMessage("Thaltej"),
        "toCompleteYourBookingPleaseRegisterOrAFreeAccount":
            MessageLookupByLibrary.simpleMessage(
                "To complete your booking, please register or a free account or sign in. This will only take a moment."),
        "tutoring": MessageLookupByLibrary.simpleMessage("Tutoring"),
        "unauthorised": MessageLookupByLibrary.simpleMessage("Unauthorised:"),
        "unknownError": MessageLookupByLibrary.simpleMessage("Unknown error"),
        "userAllowedToAccessPhotos": MessageLookupByLibrary.simpleMessage(
            "User Allowed to access photos"),
        "userDeniedToAccessPhotos": MessageLookupByLibrary.simpleMessage(
            "User Denied to access photos"),
        "vatNumber": MessageLookupByLibrary.simpleMessage("VAT Number"),
        "verificationCode":
            MessageLookupByLibrary.simpleMessage("Verification code"),
        "verify": MessageLookupByLibrary.simpleMessage("Verify"),
        "weWillNotChargeYouUntilTheServiceHasBeen":
            MessageLookupByLibrary.simpleMessage(
                "We will not charge you until the service has been completed."),
        "welComeBack": MessageLookupByLibrary.simpleMessage("Welcome back!"),
        "welcomeBack": MessageLookupByLibrary.simpleMessage("Welcome Back!"),
        "wipeDownOfCabinets":
            MessageLookupByLibrary.simpleMessage("•  Wipe down of cabinets"),
        "yes": MessageLookupByLibrary.simpleMessage("Yes"),
        "youHaveSuccessfullyCreatedYourAccount":
            MessageLookupByLibrary.simpleMessage(
                "You have successfully created your account!"),
        "yourCurrentLocation":
            MessageLookupByLibrary.simpleMessage("Your current location"),
        "yourHouseWillSparkleIncludesVacuumingFloorWashDustingAnd":
            MessageLookupByLibrary.simpleMessage(
                "Your house will sparkle. Includes vacuuming, floor wash, dusting and w..."),
        "yourPickedImage":
            MessageLookupByLibrary.simpleMessage("Your Picked Image:"),
        "youreAllSet": MessageLookupByLibrary.simpleMessage("You\'re all set")
      };
}
