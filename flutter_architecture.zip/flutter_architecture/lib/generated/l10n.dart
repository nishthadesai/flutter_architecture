// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values, avoid_escaping_inner_quotes

class S {
  S();

  static S? _current;

  static S get current {
    assert(_current != null,
        'No instance of S was loaded. Try to initialize the S delegate before accessing S.current.');
    return _current!;
  }

  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false)
        ? locale.languageCode
        : locale.toString();
    final localeName = Intl.canonicalizedLocale(name);
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      final instance = S();
      S._current = instance;

      return instance;
    });
  }

  static S of(BuildContext context) {
    final instance = S.maybeOf(context);
    assert(instance != null,
        'No instance of S present in the widget tree. Did you add S.delegate in localizationsDelegates?');
    return instance!;
  }

  static S? maybeOf(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  /// `Flutter Demo Structure`
  String get applicationTitle {
    return Intl.message(
      'Flutter Demo Structure',
      name: 'applicationTitle',
      desc: '',
      args: [],
    );
  }

  /// `The connection has timed out. Please try again`
  String get connectionTimedOut {
    return Intl.message(
      'The connection has timed out. Please try again',
      name: 'connectionTimedOut',
      desc: '',
      args: [],
    );
  }

  /// `There are some problems with the connection. Please try again`
  String get connectionProblem {
    return Intl.message(
      'There are some problems with the connection. Please try again',
      name: 'connectionProblem',
      desc: '',
      args: [],
    );
  }

  /// `Invalid credentials`
  String get invalidCredentials {
    return Intl.message(
      'Invalid credentials',
      name: 'invalidCredentials',
      desc: '',
      args: [],
    );
  }

  /// `Response is null`
  String get responseNull {
    return Intl.message(
      'Response is null',
      name: 'responseNull',
      desc: '',
      args: [],
    );
  }

  /// `Cancelled`
  String get cancelled {
    return Intl.message(
      'Cancelled',
      name: 'cancelled',
      desc: '',
      args: [],
    );
  }

  /// `Connect timeout`
  String get connectTimeout {
    return Intl.message(
      'Connect timeout',
      name: 'connectTimeout',
      desc: '',
      args: [],
    );
  }

  /// `Receive timeout`
  String get receiveTimeout {
    return Intl.message(
      'Receive timeout',
      name: 'receiveTimeout',
      desc: '',
      args: [],
    );
  }

  /// `Send timeout`
  String get sendTimeout {
    return Intl.message(
      'Send timeout',
      name: 'sendTimeout',
      desc: '',
      args: [],
    );
  }

  /// `Please check internet connection`
  String get pleaseCheckInternetConnection {
    return Intl.message(
      'Please check internet connection',
      name: 'pleaseCheckInternetConnection',
      desc: '',
      args: [],
    );
  }

  /// `Server error.`
  String get serverError {
    return Intl.message(
      'Server error.',
      name: 'serverError',
      desc: '',
      args: [],
    );
  }

  /// `Unknown error`
  String get unknownError {
    return Intl.message(
      'Unknown error',
      name: 'unknownError',
      desc: '',
      args: [],
    );
  }

  /// `Server unknown error`
  String get serverUnknownError {
    return Intl.message(
      'Server unknown error',
      name: 'serverUnknownError',
      desc: '',
      args: [],
    );
  }

  /// `Server not found`
  String get serverNotFound {
    return Intl.message(
      'Server not found',
      name: 'serverNotFound',
      desc: '',
      args: [],
    );
  }

  /// `Database exception`
  String get databaseException {
    return Intl.message(
      'Database exception',
      name: 'databaseException',
      desc: '',
      args: [],
    );
  }

  /// `Back`
  String get back {
    return Intl.message(
      'Back',
      name: 'back',
      desc: '',
      args: [],
    );
  }

  /// `Welcome back!`
  String get welComeBack {
    return Intl.message(
      'Welcome back!',
      name: 'welComeBack',
      desc: '',
      args: [],
    );
  }

  /// `Login to continue.`
  String get loginToContinue {
    return Intl.message(
      'Login to continue.',
      name: 'loginToContinue',
      desc: '',
      args: [],
    );
  }

  /// `Email Address`
  String get emailAddress {
    return Intl.message(
      'Email Address',
      name: 'emailAddress',
      desc: '',
      args: [],
    );
  }

  /// `Password`
  String get password {
    return Intl.message(
      'Password',
      name: 'password',
      desc: '',
      args: [],
    );
  }

  /// `Forgot Password?`
  String get forgotPassword {
    return Intl.message(
      'Forgot Password?',
      name: 'forgotPassword',
      desc: '',
      args: [],
    );
  }

  /// `Login`
  String get login {
    return Intl.message(
      'Login',
      name: 'login',
      desc: '',
      args: [],
    );
  }

  /// `Confirm`
  String get kConfirm {
    return Intl.message(
      'Confirm',
      name: 'kConfirm',
      desc: '',
      args: [],
    );
  }

  /// `Are you sure \n\nYou want to logout?`
  String get kLogoutMsg {
    return Intl.message(
      'Are you sure \n\nYou want to logout?',
      name: 'kLogoutMsg',
      desc: '',
      args: [],
    );
  }

  /// `Are you sure \n\nYou want to delete account?`
  String get kDeleteAccount {
    return Intl.message(
      'Are you sure \n\nYou want to delete account?',
      name: 'kDeleteAccount',
      desc: '',
      args: [],
    );
  }

  /// `Please enter email address or mobile number`
  String get kEmptyField {
    return Intl.message(
      'Please enter email address or mobile number',
      name: 'kEmptyField',
      desc: '',
      args: [],
    );
  }

  /// `Please enter country code`
  String get kEnterCountryCode {
    return Intl.message(
      'Please enter country code',
      name: 'kEnterCountryCode',
      desc: '',
      args: [],
    );
  }

  /// `Please enter mobile number`
  String get kEnterMobileNumber {
    return Intl.message(
      'Please enter mobile number',
      name: 'kEnterMobileNumber',
      desc: '',
      args: [],
    );
  }

  /// `Please enter valid mobile number`
  String get kEnterValidMobileNumber {
    return Intl.message(
      'Please enter valid mobile number',
      name: 'kEnterValidMobileNumber',
      desc: '',
      args: [],
    );
  }

  /// `Please enter valid email address`
  String get kEnterValidEmailAddress {
    return Intl.message(
      'Please enter valid email address',
      name: 'kEnterValidEmailAddress',
      desc: '',
      args: [],
    );
  }

  /// `Please enter email address`
  String get kEnterEmailAddress {
    return Intl.message(
      'Please enter email address',
      name: 'kEnterEmailAddress',
      desc: '',
      args: [],
    );
  }

  /// `Please enter first name`
  String get kEnterFirstName {
    return Intl.message(
      'Please enter first name',
      name: 'kEnterFirstName',
      desc: '',
      args: [],
    );
  }

  /// `Please enter at least 1 character for first name`
  String get kEnterValidFirstName {
    return Intl.message(
      'Please enter at least 1 character for first name',
      name: 'kEnterValidFirstName',
      desc: '',
      args: [],
    );
  }

  /// `Please enter last name`
  String get kEnterLastName {
    return Intl.message(
      'Please enter last name',
      name: 'kEnterLastName',
      desc: '',
      args: [],
    );
  }

  /// `Please enter at least 3 characters for last name`
  String get kEnterValidLastName {
    return Intl.message(
      'Please enter at least 3 characters for last name',
      name: 'kEnterValidLastName',
      desc: '',
      args: [],
    );
  }

  /// `Please enter password`
  String get kEnterPassword {
    return Intl.message(
      'Please enter password',
      name: 'kEnterPassword',
      desc: '',
      args: [],
    );
  }

  /// `Password should be 8 or more characters`
  String get kEnterValidPassword {
    return Intl.message(
      'Password should be 8 or more characters',
      name: 'kEnterValidPassword',
      desc: '',
      args: [],
    );
  }

  /// `Please enter new password`
  String get kEnterNewPassword {
    return Intl.message(
      'Please enter new password',
      name: 'kEnterNewPassword',
      desc: '',
      args: [],
    );
  }

  /// `Please enter OTP`
  String get kPleaseEnterOtp {
    return Intl.message(
      'Please enter OTP',
      name: 'kPleaseEnterOtp',
      desc: '',
      args: [],
    );
  }

  /// `Please enter valid OTP`
  String get kPleaseEnterValidOtp {
    return Intl.message(
      'Please enter valid OTP',
      name: 'kPleaseEnterValidOtp',
      desc: '',
      args: [],
    );
  }

  /// `Ok`
  String get ok {
    return Intl.message(
      'Ok',
      name: 'ok',
      desc: '',
      args: [],
    );
  }

  /// `Cancel`
  String get cancel {
    return Intl.message(
      'Cancel',
      name: 'cancel',
      desc: '',
      args: [],
    );
  }

  /// `Yes`
  String get yes {
    return Intl.message(
      'Yes',
      name: 'yes',
      desc: '',
      args: [],
    );
  }

  /// `No`
  String get no {
    return Intl.message(
      'No',
      name: 'no',
      desc: '',
      args: [],
    );
  }

  /// `Data not found`
  String get dataNotFound {
    return Intl.message(
      'Data not found',
      name: 'dataNotFound',
      desc: '',
      args: [],
    );
  }

  /// `Gallery`
  String get gallery {
    return Intl.message(
      'Gallery',
      name: 'gallery',
      desc: '',
      args: [],
    );
  }

  /// `Camera`
  String get camera {
    return Intl.message(
      'Camera',
      name: 'camera',
      desc: '',
      args: [],
    );
  }

  /// `Logout`
  String get logout {
    return Intl.message(
      'Logout',
      name: 'logout',
      desc: '',
      args: [],
    );
  }

  /// `Pick Image`
  String get pickImage {
    return Intl.message(
      'Pick Image',
      name: 'pickImage',
      desc: '',
      args: [],
    );
  }

  /// `Pick Video`
  String get pickVideo {
    return Intl.message(
      'Pick Video',
      name: 'pickVideo',
      desc: '',
      args: [],
    );
  }

  /// `Pick Documents`
  String get pickDocuments {
    return Intl.message(
      'Pick Documents',
      name: 'pickDocuments',
      desc: '',
      args: [],
    );
  }

  /// `Pick Audio`
  String get pickAudio {
    return Intl.message(
      'Pick Audio',
      name: 'pickAudio',
      desc: '',
      args: [],
    );
  }

  /// `Add New Card`
  String get addNewCard {
    return Intl.message(
      'Add New Card',
      name: 'addNewCard',
      desc: '',
      args: [],
    );
  }

  /// `Please enter your card details`
  String get addNewCardDesc {
    return Intl.message(
      'Please enter your card details',
      name: 'addNewCardDesc',
      desc: '',
      args: [],
    );
  }

  /// `Please enter card number`
  String get enterCardNumber {
    return Intl.message(
      'Please enter card number',
      name: 'enterCardNumber',
      desc: '',
      args: [],
    );
  }

  /// `Please enter card name`
  String get enterCardName {
    return Intl.message(
      'Please enter card name',
      name: 'enterCardName',
      desc: '',
      args: [],
    );
  }

  /// `Please enter expiry date`
  String get enterExpiryDate {
    return Intl.message(
      'Please enter expiry date',
      name: 'enterExpiryDate',
      desc: '',
      args: [],
    );
  }

  /// `Please enter cvv`
  String get enterCvv {
    return Intl.message(
      'Please enter cvv',
      name: 'enterCvv',
      desc: '',
      args: [],
    );
  }

  /// `Card is invalid`
  String get numberIsInvalid {
    return Intl.message(
      'Card is invalid',
      name: 'numberIsInvalid',
      desc: '',
      args: [],
    );
  }

  /// `Card Number`
  String get cardNumber {
    return Intl.message(
      'Card Number',
      name: 'cardNumber',
      desc: '',
      args: [],
    );
  }

  /// `Card Name`
  String get cardName {
    return Intl.message(
      'Card Name',
      name: 'cardName',
      desc: '',
      args: [],
    );
  }

  /// `Expiry Date`
  String get expiryDate {
    return Intl.message(
      'Expiry Date',
      name: 'expiryDate',
      desc: '',
      args: [],
    );
  }

  /// `Cvv`
  String get cvv {
    return Intl.message(
      'Cvv',
      name: 'cvv',
      desc: '',
      args: [],
    );
  }

  /// `Skip`
  String get skip {
    return Intl.message(
      'Skip',
      name: 'skip',
      desc: '',
      args: [],
    );
  }

  /// `Get Started`
  String get getStarted {
    return Intl.message(
      'Get Started',
      name: 'getStarted',
      desc: '',
      args: [],
    );
  }

  /// `Sign In With`
  String get signInWith {
    return Intl.message(
      'Sign In With',
      name: 'signInWith',
      desc: '',
      args: [],
    );
  }

  /// `Welcome Back!`
  String get welcomeBack {
    return Intl.message(
      'Welcome Back!',
      name: 'welcomeBack',
      desc: '',
      args: [],
    );
  }

  /// `Hello!`
  String get hello {
    return Intl.message(
      'Hello!',
      name: 'hello',
      desc: '',
      args: [],
    );
  }

  /// `Or`
  String get or {
    return Intl.message(
      'Or',
      name: 'or',
      desc: '',
      args: [],
    );
  }

  /// `Email`
  String get email {
    return Intl.message(
      'Email',
      name: 'email',
      desc: '',
      args: [],
    );
  }

  /// `Log in`
  String get logIn {
    return Intl.message(
      'Log in',
      name: 'logIn',
      desc: '',
      args: [],
    );
  }

  /// `Forgot?`
  String get forgot {
    return Intl.message(
      'Forgot?',
      name: 'forgot',
      desc: '',
      args: [],
    );
  }

  /// `Sign up`
  String get signUp {
    return Intl.message(
      'Sign up',
      name: 'signUp',
      desc: '',
      args: [],
    );
  }

  /// `Already have an account?`
  String get alreadyHaveAccount {
    return Intl.message(
      'Already have an account?',
      name: 'alreadyHaveAccount',
      desc: '',
      args: [],
    );
  }

  /// `Fill your below detail to create account`
  String get fillDetails {
    return Intl.message(
      'Fill your below detail to create account',
      name: 'fillDetails',
      desc: '',
      args: [],
    );
  }

  /// `Name`
  String get name {
    return Intl.message(
      'Name',
      name: 'name',
      desc: '',
      args: [],
    );
  }

  /// `Mobile Number`
  String get mobNumber {
    return Intl.message(
      'Mobile Number',
      name: 'mobNumber',
      desc: '',
      args: [],
    );
  }

  /// `Confirm Password`
  String get confPassword {
    return Intl.message(
      'Confirm Password',
      name: 'confPassword',
      desc: '',
      args: [],
    );
  }

  /// `Please enter confirm password`
  String get kConfPassword {
    return Intl.message(
      'Please enter confirm password',
      name: 'kConfPassword',
      desc: '',
      args: [],
    );
  }

  /// `I agree to `
  String get iAgree {
    return Intl.message(
      'I agree to ',
      name: 'iAgree',
      desc: '',
      args: [],
    );
  }

  /// `Terms & Conditions`
  String get tNc {
    return Intl.message(
      'Terms & Conditions',
      name: 'tNc',
      desc: '',
      args: [],
    );
  }

  /// ` and `
  String get and {
    return Intl.message(
      ' and ',
      name: 'and',
      desc: '',
      args: [],
    );
  }

  /// `Privacy Policy.`
  String get privacyPolicy {
    return Intl.message(
      'Privacy Policy.',
      name: 'privacyPolicy',
      desc: '',
      args: [],
    );
  }

  /// `Password and Confirm password not match`
  String get passwordMismatch {
    return Intl.message(
      'Password and Confirm password not match',
      name: 'passwordMismatch',
      desc: '',
      args: [],
    );
  }

  /// `Please accept $tNc $and $privacyPolicy`
  String get acceptTnC {
    return Intl.message(
      'Please accept \$tNc \$and \$privacyPolicy',
      name: 'acceptTnC',
      desc: '',
      args: [],
    );
  }

  /// `Home`
  String get home {
    return Intl.message(
      'Home',
      name: 'home',
      desc: '',
      args: [],
    );
  }

  /// `Dashboard`
  String get dashboard {
    return Intl.message(
      'Dashboard',
      name: 'dashboard',
      desc: '',
      args: [],
    );
  }

  /// `Picked file count: `
  String get pickedFileCount {
    return Intl.message(
      'Picked file count: ',
      name: 'pickedFileCount',
      desc: '',
      args: [],
    );
  }

  /// `Photo Permission`
  String get photoPermission {
    return Intl.message(
      'Photo Permission',
      name: 'photoPermission',
      desc: '',
      args: [],
    );
  }

  /// `Permission denied always user need to allow manually`
  String get permissionDeniedAlwaysUserNeedToAllowManually {
    return Intl.message(
      'Permission denied always user need to allow manually',
      name: 'permissionDeniedAlwaysUserNeedToAllowManually',
      desc: '',
      args: [],
    );
  }

  /// `User Allowed to access photos`
  String get userAllowedToAccessPhotos {
    return Intl.message(
      'User Allowed to access photos',
      name: 'userAllowedToAccessPhotos',
      desc: '',
      args: [],
    );
  }

  /// `User Denied to access photos`
  String get userDeniedToAccessPhotos {
    return Intl.message(
      'User Denied to access photos',
      name: 'userDeniedToAccessPhotos',
      desc: '',
      args: [],
    );
  }

  /// `Search...`
  String get search {
    return Intl.message(
      'Search...',
      name: 'search',
      desc: '',
      args: [],
    );
  }

  /// `Select your phone code`
  String get selectYourPhoneCode {
    return Intl.message(
      'Select your phone code',
      name: 'selectYourPhoneCode',
      desc: '',
      args: [],
    );
  }

  /// `Error During Communication:`
  String get errorDuringCommunication {
    return Intl.message(
      'Error During Communication:',
      name: 'errorDuringCommunication',
      desc: '',
      args: [],
    );
  }

  /// `Invalid Request:`
  String get invalidRequest {
    return Intl.message(
      'Invalid Request:',
      name: 'invalidRequest',
      desc: '',
      args: [],
    );
  }

  /// `Unauthorised:`
  String get unauthorised {
    return Intl.message(
      'Unauthorised:',
      name: 'unauthorised',
      desc: '',
      args: [],
    );
  }

  /// `Invalid Input:`
  String get invalidInput {
    return Intl.message(
      'Invalid Input:',
      name: 'invalidInput',
      desc: '',
      args: [],
    );
  }

  /// `No Active Internet Connection`
  String get noActiveInternetConnection {
    return Intl.message(
      'No Active Internet Connection',
      name: 'noActiveInternetConnection',
      desc: '',
      args: [],
    );
  }

  /// `Connection to server failed due to internet connection.`
  String get connectionToServerFailedDueToInternetConnection {
    return Intl.message(
      'Connection to server failed due to internet connection.',
      name: 'connectionToServerFailedDueToInternetConnection',
      desc: '',
      args: [],
    );
  }

  /// `Something went wrong. Please try after sometime.`
  String get somethingWentWrongPleaseTryAfterSometime {
    return Intl.message(
      'Something went wrong. Please try after sometime.',
      name: 'somethingWentWrongPleaseTryAfterSometime',
      desc: '',
      args: [],
    );
  }

  /// `Request to server was cancelled`
  String get requestToServerWasCancelled {
    return Intl.message(
      'Request to server was cancelled',
      name: 'requestToServerWasCancelled',
      desc: '',
      args: [],
    );
  }

  /// `Connection timeout with server`
  String get connectionTimeoutWithServer {
    return Intl.message(
      'Connection timeout with server',
      name: 'connectionTimeoutWithServer',
      desc: '',
      args: [],
    );
  }

  /// `Request can't be handled for now. Please try after sometime.`
  String get requestCantBeHandledForNowPleaseTryAfterSometime {
    return Intl.message(
      'Request can\'t be handled for now. Please try after sometime.',
      name: 'requestCantBeHandledForNowPleaseTryAfterSometime',
      desc: '',
      args: [],
    );
  }

  /// `Please login again.`
  String get pleaseLoginAgain {
    return Intl.message(
      'Please login again.',
      name: 'pleaseLoginAgain',
      desc: '',
      args: [],
    );
  }

  /// `Something when wrong. Please try again.`
  String get somethingWhenWrongPleaseTryAgain {
    return Intl.message(
      'Something when wrong. Please try again.',
      name: 'somethingWhenWrongPleaseTryAgain',
      desc: '',
      args: [],
    );
  }

  /// `Error uploading photo`
  String get errorUploadingPhoto {
    return Intl.message(
      'Error uploading photo',
      name: 'errorUploadingPhoto',
      desc: '',
      args: [],
    );
  }

  /// `CVV is invalid`
  String get cvvIsInvalid {
    return Intl.message(
      'CVV is invalid',
      name: 'cvvIsInvalid',
      desc: '',
      args: [],
    );
  }

  /// `Expiry month is invalid`
  String get expiryMonthIsInvalid {
    return Intl.message(
      'Expiry month is invalid',
      name: 'expiryMonthIsInvalid',
      desc: '',
      args: [],
    );
  }

  /// `Expiry year is invalid`
  String get expiryYearIsInvalid {
    return Intl.message(
      'Expiry year is invalid',
      name: 'expiryYearIsInvalid',
      desc: '',
      args: [],
    );
  }

  /// `Card has expired`
  String get cardHasExpired {
    return Intl.message(
      'Card has expired',
      name: 'cardHasExpired',
      desc: '',
      args: [],
    );
  }

  /// `Please check your internet connection`
  String get pleaseCheckYourInternetConnection {
    return Intl.message(
      'Please check your internet connection',
      name: 'pleaseCheckYourInternetConnection',
      desc: '',
      args: [],
    );
  }

  /// `Add employee`
  String get addEmployee {
    return Intl.message(
      'Add employee',
      name: 'addEmployee',
      desc: '',
      args: [],
    );
  }

  /// `Sola`
  String get sola {
    return Intl.message(
      'Sola',
      name: 'sola',
      desc: '',
      args: [],
    );
  }

  /// `Gota`
  String get gota {
    return Intl.message(
      'Gota',
      name: 'gota',
      desc: '',
      args: [],
    );
  }

  /// `Thaltej`
  String get thaltej {
    return Intl.message(
      'Thaltej',
      name: 'thaltej',
      desc: '',
      args: [],
    );
  }

  /// `Prahlad Nagar`
  String get prahladNagar {
    return Intl.message(
      'Prahlad Nagar',
      name: 'prahladNagar',
      desc: '',
      args: [],
    );
  }

  /// `Tasks around the house`
  String get tasksAroundTheHouse {
    return Intl.message(
      'Tasks around the house',
      name: 'tasksAroundTheHouse',
      desc: '',
      args: [],
    );
  }

  /// `Gift wrapping`
  String get giftWrapping {
    return Intl.message(
      'Gift wrapping',
      name: 'giftWrapping',
      desc: '',
      args: [],
    );
  }

  /// `Avg. price 200 dkk`
  String get avgPrice200Dkk {
    return Intl.message(
      'Avg. price 200 dkk',
      name: 'avgPrice200Dkk',
      desc: '',
      args: [],
    );
  }

  /// `Avg. price 300 dkk`
  String get avgPrice300Dkk {
    return Intl.message(
      'Avg. price 300 dkk',
      name: 'avgPrice300Dkk',
      desc: '',
      args: [],
    );
  }

  /// `Avg. price 400 dkk`
  String get avgPrice400Dkk {
    return Intl.message(
      'Avg. price 400 dkk',
      name: 'avgPrice400Dkk',
      desc: '',
      args: [],
    );
  }

  /// `Your current location`
  String get yourCurrentLocation {
    return Intl.message(
      'Your current location',
      name: 'yourCurrentLocation',
      desc: '',
      args: [],
    );
  }

  /// `Popular projects in your area`
  String get popularProjectsInYourArea {
    return Intl.message(
      'Popular projects in your area',
      name: 'popularProjectsInYourArea',
      desc: '',
      args: [],
    );
  }

  /// `I need help with:`
  String get iNeedHelpWith {
    return Intl.message(
      'I need help with:',
      name: 'iNeedHelpWith',
      desc: '',
      args: [],
    );
  }

  /// `House Cleaning`
  String get houseCleaning {
    return Intl.message(
      'House Cleaning',
      name: 'houseCleaning',
      desc: '',
      args: [],
    );
  }

  /// `Tutoring`
  String get tutoring {
    return Intl.message(
      'Tutoring',
      name: 'tutoring',
      desc: '',
      args: [],
    );
  }

  /// `Handy Work`
  String get handyWork {
    return Intl.message(
      'Handy Work',
      name: 'handyWork',
      desc: '',
      args: [],
    );
  }

  /// `Childcare`
  String get childcare {
    return Intl.message(
      'Childcare',
      name: 'childcare',
      desc: '',
      args: [],
    );
  }

  /// `Pet Care`
  String get petCare {
    return Intl.message(
      'Pet Care',
      name: 'petCare',
      desc: '',
      args: [],
    );
  }

  /// `Featured helpers:`
  String get featuredHelpers {
    return Intl.message(
      'Featured helpers:',
      name: 'featuredHelpers',
      desc: '',
      args: [],
    );
  }

  /// `Booking`
  String get booking {
    return Intl.message(
      'Booking',
      name: 'booking',
      desc: '',
      args: [],
    );
  }

  /// `Profile`
  String get profile {
    return Intl.message(
      'Profile',
      name: 'profile',
      desc: '',
      args: [],
    );
  }

  /// `My Bookings(2)`
  String get myBookings2 {
    return Intl.message(
      'My Bookings(2)',
      name: 'myBookings2',
      desc: '',
      args: [],
    );
  }

  /// `Jason Roy`
  String get jasonRoy {
    return Intl.message(
      'Jason Roy',
      name: 'jasonRoy',
      desc: '',
      args: [],
    );
  }

  /// `Newyork, USA`
  String get newyorkUsa {
    return Intl.message(
      'Newyork, USA',
      name: 'newyorkUsa',
      desc: '',
      args: [],
    );
  }

  /// `I am thorough, friendly and honest. I will leave your sp...`
  String get iAmThoroughFriendlyAndHonestIWillLeaveYour {
    return Intl.message(
      'I am thorough, friendly and honest. I will leave your sp...',
      name: 'iAmThoroughFriendlyAndHonestIWillLeaveYour',
      desc: '',
      args: [],
    );
  }

  /// `I can help you with`
  String get iCanHelpYouWith {
    return Intl.message(
      'I can help you with',
      name: 'iCanHelpYouWith',
      desc: '',
      args: [],
    );
  }

  /// `140 dkk / hour`
  String get DkkHour {
    return Intl.message(
      '140 dkk / hour',
      name: 'DkkHour',
      desc: '',
      args: [],
    );
  }

  /// `“Sanne was wonderful with my son who needed loving care with math...”`
  String get sanneWasWonderfulWithMySonWhoNeededLovingCare {
    return Intl.message(
      '“Sanne was wonderful with my son who needed loving care with math...”',
      name: 'sanneWasWonderfulWithMySonWhoNeededLovingCare',
      desc: '',
      args: [],
    );
  }

  /// `Our taskers will make your space shine!`
  String get ourTaskersWillMakeYourSpaceShine {
    return Intl.message(
      'Our taskers will make your space shine!',
      name: 'ourTaskersWillMakeYourSpaceShine',
      desc: '',
      args: [],
    );
  }

  /// `Available cleaning services`
  String get availableCleaningServices {
    return Intl.message(
      'Available cleaning services',
      name: 'availableCleaningServices',
      desc: '',
      args: [],
    );
  }

  /// `Read more`
  String get readMore {
    return Intl.message(
      'Read more',
      name: 'readMore',
      desc: '',
      args: [],
    );
  }

  /// `Math tutoring`
  String get mathTutoring {
    return Intl.message(
      'Math tutoring',
      name: 'mathTutoring',
      desc: '',
      args: [],
    );
  }

  /// `Cooking`
  String get cooking {
    return Intl.message(
      'Cooking',
      name: 'cooking',
      desc: '',
      args: [],
    );
  }

  /// `Full house cleaning`
  String get fullHouseCleaning {
    return Intl.message(
      'Full house cleaning',
      name: 'fullHouseCleaning',
      desc: '',
      args: [],
    );
  }

  /// `Your house will sparkle. Includes vacuuming, floor wash, dusting and w...`
  String get yourHouseWillSparkleIncludesVacuumingFloorWashDustingAnd {
    return Intl.message(
      'Your house will sparkle. Includes vacuuming, floor wash, dusting and w...',
      name: 'yourHouseWillSparkleIncludesVacuumingFloorWashDustingAnd',
      desc: '',
      args: [],
    );
  }

  /// `Deep house cleaning`
  String get deepHouseCleaning {
    return Intl.message(
      'Deep house cleaning',
      name: 'deepHouseCleaning',
      desc: '',
      args: [],
    );
  }

  /// `A deep clean with full wipe down of all surfaces, oven, and more...`
  String get aDeepCleanWithFullWipeDownOfAllSurfaces {
    return Intl.message(
      'A deep clean with full wipe down of all surfaces, oven, and more...',
      name: 'aDeepCleanWithFullWipeDownOfAllSurfaces',
      desc: '',
      args: [],
    );
  }

  /// `Move in / out  cleaning`
  String get moveInOutCleaning {
    return Intl.message(
      'Move in / out  cleaning',
      name: 'moveInOutCleaning',
      desc: '',
      args: [],
    );
  }

  /// `Other`
  String get other {
    return Intl.message(
      'Other',
      name: 'other',
      desc: '',
      args: [],
    );
  }

  /// `Have something specific you need help with? Choose number of hours and ...`
  String get haveSomethingSpecificYouNeedHelpWithChooseNumberOf {
    return Intl.message(
      'Have something specific you need help with? Choose number of hours and ...',
      name: 'haveSomethingSpecificYouNeedHelpWithChooseNumberOf',
      desc: '',
      args: [],
    );
  }

  /// `93 reviews`
  String get Reviews {
    return Intl.message(
      '93 reviews',
      name: 'Reviews',
      desc: '',
      args: [],
    );
  }

  /// `latitude`
  String get latitude {
    return Intl.message(
      'latitude',
      name: 'latitude',
      desc: '',
      args: [],
    );
  }

  /// `longitude`
  String get longitude {
    return Intl.message(
      'longitude',
      name: 'longitude',
      desc: '',
      args: [],
    );
  }

  /// `Retry`
  String get retry {
    return Intl.message(
      'Retry',
      name: 'retry',
      desc: '',
      args: [],
    );
  }

  /// `Please check your internet connectivity and try again`
  String get pleaseCheckYourInternetConnectivityAndTryAgain {
    return Intl.message(
      'Please check your internet connectivity and try again',
      name: 'pleaseCheckYourInternetConnectivityAndTryAgain',
      desc: '',
      args: [],
    );
  }

  /// `No Connection`
  String get noConnection {
    return Intl.message(
      'No Connection',
      name: 'noConnection',
      desc: '',
      args: [],
    );
  }

  /// `category_id`
  String get categoryid {
    return Intl.message(
      'category_id',
      name: 'categoryid',
      desc: '',
      args: [],
    );
  }

  /// `Low`
  String get low {
    return Intl.message(
      'Low',
      name: 'low',
      desc: '',
      args: [],
    );
  }

  /// `Medium`
  String get medium {
    return Intl.message(
      'Medium',
      name: 'medium',
      desc: '',
      args: [],
    );
  }

  /// `High`
  String get high {
    return Intl.message(
      'High',
      name: 'high',
      desc: '',
      args: [],
    );
  }

  /// `Details:`
  String get details {
    return Intl.message(
      'Details:',
      name: 'details',
      desc: '',
      args: [],
    );
  }

  /// `•  Floor vacuum and wash`
  String get floorVacuumAndWash {
    return Intl.message(
      '•  Floor vacuum and wash',
      name: 'floorVacuumAndWash',
      desc: '',
      args: [],
    );
  }

  /// `•  Dusting all surfaces`
  String get dustingAllSurfaces {
    return Intl.message(
      '•  Dusting all surfaces',
      name: 'dustingAllSurfaces',
      desc: '',
      args: [],
    );
  }

  /// `•  Wipe down of cabinets`
  String get wipeDownOfCabinets {
    return Intl.message(
      '•  Wipe down of cabinets',
      name: 'wipeDownOfCabinets',
      desc: '',
      args: [],
    );
  }

  /// `•  1 bathroom cleaned`
  String get BathroomCleaned {
    return Intl.message(
      '•  1 bathroom cleaned',
      name: 'BathroomCleaned',
      desc: '',
      args: [],
    );
  }

  /// `•  1 kitchen cleaned`
  String get KitchenCleaned {
    return Intl.message(
      '•  1 kitchen cleaned',
      name: 'KitchenCleaned',
      desc: '',
      args: [],
    );
  }

  /// `Read Less`
  String get readLess {
    return Intl.message(
      'Read Less',
      name: 'readLess',
      desc: '',
      args: [],
    );
  }

  /// `Task Details`
  String get taskDetails {
    return Intl.message(
      'Task Details',
      name: 'taskDetails',
      desc: '',
      args: [],
    );
  }

  /// `How often?`
  String get howOften {
    return Intl.message(
      'How often?',
      name: 'howOften',
      desc: '',
      args: [],
    );
  }

  /// `Select frequency for cleaning`
  String get selectFrequencyForCleaning {
    return Intl.message(
      'Select frequency for cleaning',
      name: 'selectFrequencyForCleaning',
      desc: '',
      args: [],
    );
  }

  /// `Additional services`
  String get additionalServices {
    return Intl.message(
      'Additional services',
      name: 'additionalServices',
      desc: '',
      args: [],
    );
  }

  /// `Please select frequency`
  String get pleaseSelectFrequency {
    return Intl.message(
      'Please select frequency',
      name: 'pleaseSelectFrequency',
      desc: '',
      args: [],
    );
  }

  /// `Next`
  String get next {
    return Intl.message(
      'Next',
      name: 'next',
      desc: '',
      args: [],
    );
  }

  /// `Deep kitchen cleaning`
  String get deepKitchenCleaning {
    return Intl.message(
      'Deep kitchen cleaning',
      name: 'deepKitchenCleaning',
      desc: '',
      args: [],
    );
  }

  /// `Additional bathroom`
  String get additionalBathroom {
    return Intl.message(
      'Additional bathroom',
      name: 'additionalBathroom',
      desc: '',
      args: [],
    );
  }

  /// `Oven cleaning`
  String get ovenCleaning {
    return Intl.message(
      'Oven cleaning',
      name: 'ovenCleaning',
      desc: '',
      args: [],
    );
  }

  /// `Car wash`
  String get carWash {
    return Intl.message(
      'Car wash',
      name: 'carWash',
      desc: '',
      args: [],
    );
  }

  /// `+ 1  hour`
  String get Hour {
    return Intl.message(
      '+ 1  hour',
      name: 'Hour',
      desc: '',
      args: [],
    );
  }

  /// `Location permissions are permanently denied, we cannot request permissions.`
  String get locationPermissionsArePermanentlyDeniedWeCannotRequestPermissions {
    return Intl.message(
      'Location permissions are permanently denied, we cannot request permissions.',
      name: 'locationPermissionsArePermanentlyDeniedWeCannotRequestPermissions',
      desc: '',
      args: [],
    );
  }

  /// `Location permissions are denied`
  String get locationPermissionsAreDenied {
    return Intl.message(
      'Location permissions are denied',
      name: 'locationPermissionsAreDenied',
      desc: '',
      args: [],
    );
  }

  /// `Please turn on location`
  String get pleaseTurnOnLocation {
    return Intl.message(
      'Please turn on location',
      name: 'pleaseTurnOnLocation',
      desc: '',
      args: [],
    );
  }

  /// `Lorem Ipsum is simply dummy text of the printing and typesetting industry`
  String get loremIpsumIsSimplyDummyTextOfThePrintingAnd {
    return Intl.message(
      'Lorem Ipsum is simply dummy text of the printing and typesetting industry',
      name: 'loremIpsumIsSimplyDummyTextOfThePrintingAnd',
      desc: '',
      args: [],
    );
  }

  /// `No data found`
  String get noDataFound {
    return Intl.message(
      'No data found',
      name: 'noDataFound',
      desc: '',
      args: [],
    );
  }

  /// `Need to register`
  String get needToRegister {
    return Intl.message(
      'Need to register',
      name: 'needToRegister',
      desc: '',
      args: [],
    );
  }

  /// `Create account`
  String get createAccount {
    return Intl.message(
      'Create account',
      name: 'createAccount',
      desc: '',
      args: [],
    );
  }

  /// `Already have an account?`
  String get alreadyHaveAnAccount {
    return Intl.message(
      'Already have an account?',
      name: 'alreadyHaveAnAccount',
      desc: '',
      args: [],
    );
  }

  /// `Profile information`
  String get profileInformation {
    return Intl.message(
      'Profile information',
      name: 'profileInformation',
      desc: '',
      args: [],
    );
  }

  /// `Please turn on internet Connection`
  String get pleaseTurnOnInternetConnection {
    return Intl.message(
      'Please turn on internet Connection',
      name: 'pleaseTurnOnInternetConnection',
      desc: '',
      args: [],
    );
  }

  /// `To complete your booking, please register or a free account or sign in. This will only take a moment.`
  String get toCompleteYourBookingPleaseRegisterOrAFreeAccount {
    return Intl.message(
      'To complete your booking, please register or a free account or sign in. This will only take a moment.',
      name: 'toCompleteYourBookingPleaseRegisterOrAFreeAccount',
      desc: '',
      args: [],
    );
  }

  /// `First Name`
  String get firstName {
    return Intl.message(
      'First Name',
      name: 'firstName',
      desc: '',
      args: [],
    );
  }

  /// `Last Name`
  String get lastName {
    return Intl.message(
      'Last Name',
      name: 'lastName',
      desc: '',
      args: [],
    );
  }

  /// `Enter First Name`
  String get enterFirstName {
    return Intl.message(
      'Enter First Name',
      name: 'enterFirstName',
      desc: '',
      args: [],
    );
  }

  /// `Enter Last Name`
  String get enterLastName {
    return Intl.message(
      'Enter Last Name',
      name: 'enterLastName',
      desc: '',
      args: [],
    );
  }

  /// `Mobile Number`
  String get mobileNumber {
    return Intl.message(
      'Mobile Number',
      name: 'mobileNumber',
      desc: '',
      args: [],
    );
  }

  /// `Enter Mobile Number`
  String get enterMobileNumber {
    return Intl.message(
      'Enter Mobile Number',
      name: 'enterMobileNumber',
      desc: '',
      args: [],
    );
  }

  /// `DK`
  String get dk {
    return Intl.message(
      'DK',
      name: 'dk',
      desc: '',
      args: [],
    );
  }

  /// `Login information`
  String get loginInformation {
    return Intl.message(
      'Login information',
      name: 'loginInformation',
      desc: '',
      args: [],
    );
  }

  /// `Enter Email`
  String get enterEmail {
    return Intl.message(
      'Enter Email',
      name: 'enterEmail',
      desc: '',
      args: [],
    );
  }

  /// `Enter Password`
  String get enterPassword {
    return Intl.message(
      'Enter Password',
      name: 'enterPassword',
      desc: '',
      args: [],
    );
  }

  /// `Confirm Password`
  String get confirmPassword {
    return Intl.message(
      'Confirm Password',
      name: 'confirmPassword',
      desc: '',
      args: [],
    );
  }

  /// `Enter confirm password`
  String get enterConfirmPassword {
    return Intl.message(
      'Enter confirm password',
      name: 'enterConfirmPassword',
      desc: '',
      args: [],
    );
  }

  /// `Confirm password must be same as password`
  String get confirmPasswordMustBeSameAsPassword {
    return Intl.message(
      'Confirm password must be same as password',
      name: 'confirmPasswordMustBeSameAsPassword',
      desc: '',
      args: [],
    );
  }

  /// `Billing and payment details`
  String get billingAndPaymentDetails {
    return Intl.message(
      'Billing and payment details',
      name: 'billingAndPaymentDetails',
      desc: '',
      args: [],
    );
  }

  /// `Billing address is different than service address`
  String get billingAddressIsDifferentThanServiceAddress {
    return Intl.message(
      'Billing address is different than service address',
      name: 'billingAddressIsDifferentThanServiceAddress',
      desc: '',
      args: [],
    );
  }

  /// `VAT Number`
  String get vatNumber {
    return Intl.message(
      'VAT Number',
      name: 'vatNumber',
      desc: '',
      args: [],
    );
  }

  /// `Enter VAT number`
  String get enterVatNumber {
    return Intl.message(
      'Enter VAT number',
      name: 'enterVatNumber',
      desc: '',
      args: [],
    );
  }

  /// `Payment method`
  String get paymentMethod {
    return Intl.message(
      'Payment method',
      name: 'paymentMethod',
      desc: '',
      args: [],
    );
  }

  /// `Change`
  String get change {
    return Intl.message(
      'Change',
      name: 'change',
      desc: '',
      args: [],
    );
  }

  /// `We will not charge you until the service has been completed.`
  String get weWillNotChargeYouUntilTheServiceHasBeen {
    return Intl.message(
      'We will not charge you until the service has been completed.',
      name: 'weWillNotChargeYouUntilTheServiceHasBeen',
      desc: '',
      args: [],
    );
  }

  /// `Jane Smith`
  String get janeSmith {
    return Intl.message(
      'Jane Smith',
      name: 'janeSmith',
      desc: '',
      args: [],
    );
  }

  /// `By continuing, you agree to the`
  String get byContinuingYouAgreeToThe {
    return Intl.message(
      'By continuing, you agree to the',
      name: 'byContinuingYouAgreeToThe',
      desc: '',
      args: [],
    );
  }

  /// `Terms of Service`
  String get termsOfService {
    return Intl.message(
      'Terms of Service',
      name: 'termsOfService',
      desc: '',
      args: [],
    );
  }

  /// `Sign up & continue to confirmation`
  String get signUpContinueToConfirmation {
    return Intl.message(
      'Sign up & continue to confirmation',
      name: 'signUpContinueToConfirmation',
      desc: '',
      args: [],
    );
  }

  /// `Please fill form properly`
  String get pleaseFillFormProperly {
    return Intl.message(
      'Please fill form properly',
      name: 'pleaseFillFormProperly',
      desc: '',
      args: [],
    );
  }

  /// `Please enter vat number`
  String get pleaseEnterVatNumber {
    return Intl.message(
      'Please enter vat number',
      name: 'pleaseEnterVatNumber',
      desc: '',
      args: [],
    );
  }

  /// `Please accept privacy policy`
  String get pleaseAcceptPrivacyPolicy {
    return Intl.message(
      'Please accept privacy policy',
      name: 'pleaseAcceptPrivacyPolicy',
      desc: '',
      args: [],
    );
  }

  /// `Successfully Signed up`
  String get successfullySignedUp {
    return Intl.message(
      'Successfully Signed up',
      name: 'successfullySignedUp',
      desc: '',
      args: [],
    );
  }

  /// `Enter the 4 digit verification code we sent to you via SMS.`
  String get enterThe4DigitVerificationCodeWeSentToYou {
    return Intl.message(
      'Enter the 4 digit verification code we sent to you via SMS.',
      name: 'enterThe4DigitVerificationCodeWeSentToYou',
      desc: '',
      args: [],
    );
  }

  /// `Verification code`
  String get verificationCode {
    return Intl.message(
      'Verification code',
      name: 'verificationCode',
      desc: '',
      args: [],
    );
  }

  /// `Resend`
  String get resend {
    return Intl.message(
      'Resend',
      name: 'resend',
      desc: '',
      args: [],
    );
  }

  /// `Verify`
  String get verify {
    return Intl.message(
      'Verify',
      name: 'verify',
      desc: '',
      args: [],
    );
  }

  /// `Please enter otp`
  String get pleaseEnterOtp {
    return Intl.message(
      'Please enter otp',
      name: 'pleaseEnterOtp',
      desc: '',
      args: [],
    );
  }

  /// `You have successfully created your account!`
  String get youHaveSuccessfullyCreatedYourAccount {
    return Intl.message(
      'You have successfully created your account!',
      name: 'youHaveSuccessfullyCreatedYourAccount',
      desc: '',
      args: [],
    );
  }

  /// `You're all set`
  String get youreAllSet {
    return Intl.message(
      'You\'re all set',
      name: 'youreAllSet',
      desc: '',
      args: [],
    );
  }

  /// `Back to login`
  String get backToLogin {
    return Intl.message(
      'Back to login',
      name: 'backToLogin',
      desc: '',
      args: [],
    );
  }

  /// `Enter address`
  String get enterAddress {
    return Intl.message(
      'Enter address',
      name: 'enterAddress',
      desc: '',
      args: [],
    );
  }

  /// `Please enter address`
  String get pleaseEnterAddress {
    return Intl.message(
      'Please enter address',
      name: 'pleaseEnterAddress',
      desc: '',
      args: [],
    );
  }

  /// `Otp sent succesfully`
  String get otpSentSuccesfully {
    return Intl.message(
      'Otp sent succesfully',
      name: 'otpSentSuccesfully',
      desc: '',
      args: [],
    );
  }

  /// `Please enter 4 digit otp`
  String get pleaseEnter4DigitOtp {
    return Intl.message(
      'Please enter 4 digit otp',
      name: 'pleaseEnter4DigitOtp',
      desc: '',
      args: [],
    );
  }

  /// `Pick an Image`
  String get pickAnImage {
    return Intl.message(
      'Pick an Image',
      name: 'pickAnImage',
      desc: '',
      args: [],
    );
  }

  /// `Choose Image`
  String get chooseImage {
    return Intl.message(
      'Choose Image',
      name: 'chooseImage',
      desc: '',
      args: [],
    );
  }

  /// `Permission denied, please give permission`
  String get permissionDeniedPleaseGivePermission {
    return Intl.message(
      'Permission denied, please give permission',
      name: 'permissionDeniedPleaseGivePermission',
      desc: '',
      args: [],
    );
  }

  /// `No image selected`
  String get noImageSelected {
    return Intl.message(
      'No image selected',
      name: 'noImageSelected',
      desc: '',
      args: [],
    );
  }

  /// `Your Picked Image:`
  String get yourPickedImage {
    return Intl.message(
      'Your Picked Image:',
      name: 'yourPickedImage',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return true;
      }
    }
    return false;
  }
}
