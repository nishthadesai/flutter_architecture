abstract class APIEndPoints {
  APIEndPoints._();
  // static String baseUrl = 'https://www.dummy.com/';
  // static String login = 'user/login';
  static String baseUrl = 'http://3.122.161.237:4103/api/v1/';
  static String home = 'user/home';
  static String subcategory = 'user/sub_category_list';
  static String signUp = 'user/signup';
  static String otp = 'user/send_otp';
  // static String baseUrl = 'https://fakeapi.platzi.com/';
  // static String imageUpload = 'en/rest/files/';
}
