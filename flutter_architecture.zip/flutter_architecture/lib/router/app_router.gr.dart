// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouterGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

part of 'app_router.dart';

abstract class _$AppRouter extends RootStackRouter {
  // ignore: unused_element
  _$AppRouter({super.navigatorKey});

  @override
  final Map<String, PageFactory> pagesMap = {
    BottomNavigationBarRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const BottomNavigationBarPage(),
      );
    },
    HomeRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const HomePage(),
      );
    },
    HouseCleaningDetailsRoute.name: (routeData) {
      final args = routeData.argsAs<HouseCleaningDetailsRouteArgs>();
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: HouseCleaningDetailsPage(
          id: args.id,
          tag: args.tag,
          image: args.image,
          description: args.description,
        ),
      );
    },
    ImagePickerRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const ImagePickerPage(),
      );
    },
    LoginRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const LoginPage(),
      );
    },
    ServiceListDetailsRoute.name: (routeData) {
      final args = routeData.argsAs<ServiceListDetailsRouteArgs>();
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: ServiceListDetailsPage(
          image: args.image,
          desc: args.desc,
          tag: args.tag,
        ),
      );
    },
    ShowUploadedImageRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const ShowUploadedImagePage(),
      );
    },
    SignUpFormRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const SignUpFormPage(),
      );
    },
    SignUpRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const SignUpPage(),
      );
    },
    SplashRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const SplashPage(),
      );
    },
  };
}

/// generated route for
/// [BottomNavigationBarPage]
class BottomNavigationBarRoute extends PageRouteInfo<void> {
  const BottomNavigationBarRoute({List<PageRouteInfo>? children})
      : super(
          BottomNavigationBarRoute.name,
          initialChildren: children,
        );

  static const String name = 'BottomNavigationBarRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [HomePage]
class HomeRoute extends PageRouteInfo<void> {
  const HomeRoute({List<PageRouteInfo>? children})
      : super(
          HomeRoute.name,
          initialChildren: children,
        );

  static const String name = 'HomeRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [HouseCleaningDetailsPage]
class HouseCleaningDetailsRoute
    extends PageRouteInfo<HouseCleaningDetailsRouteArgs> {
  HouseCleaningDetailsRoute({
    Key? key,
    required int id,
    required String tag,
    required String image,
    required String description,
    List<PageRouteInfo>? children,
  }) : super(
          HouseCleaningDetailsRoute.name,
          args: HouseCleaningDetailsRouteArgs(
            key: key,
            id: id,
            tag: tag,
            image: image,
            description: description,
          ),
          initialChildren: children,
        );

  static const String name = 'HouseCleaningDetailsRoute';

  static const PageInfo<HouseCleaningDetailsRouteArgs> page =
      PageInfo<HouseCleaningDetailsRouteArgs>(name);
}

class HouseCleaningDetailsRouteArgs {
  const HouseCleaningDetailsRouteArgs({
    this.key,
    required this.id,
    required this.tag,
    required this.image,
    required this.description,
  });

  final Key? key;

  final int id;

  final String tag;

  final String image;

  final String description;

  @override
  String toString() {
    return 'HouseCleaningDetailsRouteArgs{key: $key, id: $id, tag: $tag, image: $image, description: $description}';
  }
}

/// generated route for
/// [ImagePickerPage]
class ImagePickerRoute extends PageRouteInfo<void> {
  const ImagePickerRoute({List<PageRouteInfo>? children})
      : super(
          ImagePickerRoute.name,
          initialChildren: children,
        );

  static const String name = 'ImagePickerRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [LoginPage]
class LoginRoute extends PageRouteInfo<void> {
  const LoginRoute({List<PageRouteInfo>? children})
      : super(
          LoginRoute.name,
          initialChildren: children,
        );

  static const String name = 'LoginRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [ServiceListDetailsPage]
class ServiceListDetailsRoute
    extends PageRouteInfo<ServiceListDetailsRouteArgs> {
  ServiceListDetailsRoute({
    Key? key,
    required String image,
    required String desc,
    required String tag,
    List<PageRouteInfo>? children,
  }) : super(
          ServiceListDetailsRoute.name,
          args: ServiceListDetailsRouteArgs(
            key: key,
            image: image,
            desc: desc,
            tag: tag,
          ),
          initialChildren: children,
        );

  static const String name = 'ServiceListDetailsRoute';

  static const PageInfo<ServiceListDetailsRouteArgs> page =
      PageInfo<ServiceListDetailsRouteArgs>(name);
}

class ServiceListDetailsRouteArgs {
  const ServiceListDetailsRouteArgs({
    this.key,
    required this.image,
    required this.desc,
    required this.tag,
  });

  final Key? key;

  final String image;

  final String desc;

  final String tag;

  @override
  String toString() {
    return 'ServiceListDetailsRouteArgs{key: $key, image: $image, desc: $desc, tag: $tag}';
  }
}

/// generated route for
/// [ShowUploadedImagePage]
class ShowUploadedImageRoute extends PageRouteInfo<void> {
  const ShowUploadedImageRoute({List<PageRouteInfo>? children})
      : super(
          ShowUploadedImageRoute.name,
          initialChildren: children,
        );

  static const String name = 'ShowUploadedImageRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [SignUpFormPage]
class SignUpFormRoute extends PageRouteInfo<void> {
  const SignUpFormRoute({List<PageRouteInfo>? children})
      : super(
          SignUpFormRoute.name,
          initialChildren: children,
        );

  static const String name = 'SignUpFormRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [SignUpPage]
class SignUpRoute extends PageRouteInfo<void> {
  const SignUpRoute({List<PageRouteInfo>? children})
      : super(
          SignUpRoute.name,
          initialChildren: children,
        );

  static const String name = 'SignUpRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [SplashPage]
class SplashRoute extends PageRouteInfo<void> {
  const SplashRoute({List<PageRouteInfo>? children})
      : super(
          SplashRoute.name,
          initialChildren: children,
        );

  static const String name = 'SplashRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}
